# Thank you for downloading GLASS!

## Getting Started

Check out our [documentation](<https://glass-project.com/documentation>) for an in-depth guide on how to use GLASS!

## License

Please make sure you understand the contents of our [usage license](<./LICENSE.txt>). A brief summary of the license is as follows:
* This tool is free to use and free to share
* The license must be included in all copys of this tool
* This tool may not be used for commercial purposes
* Modified versions of this tool may not be distributed
* This tool comes as is, with no warranty

## Copyright

Copyright (C) 2024 Tommy Galletta, Alexander Lockard

Contact **contact.glass.project@gmail.com** for more information